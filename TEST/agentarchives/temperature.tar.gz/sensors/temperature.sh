#!/bin/bash
while true
do
    echo "20.0"
    sleep 2
done

