#!/bin/bash
while true
do
    echo "42"
    sleep 20
done

